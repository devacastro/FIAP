package controle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import conexao.PedidoDAO;
import modelo.Pedido;
import modelo.Produto;

/**
 * Servlet implementation class CadastroPedidosServlet
 */
@WebServlet(name = "cadastropedido", urlPatterns = { "/cadastropedido" })
public class CadastroPedidosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CadastroPedidosServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nomeContato = request.getParameter("nomecontato");
		String enderecoContato = request.getParameter("endereco");
		Integer produtoID = Integer.parseInt(request.getParameter("produto"));
		Integer quantidade = Integer.parseInt(request.getParameter("quantidade"));
		Double total = Double.parseDouble(request.getParameter("total"));
		
		Produto produto = new Produto();
		produto.setId(produtoID);
		
		Pedido pedido = new Pedido();
		pedido.setNomeContato(nomeContato);
		pedido.setEnderecoContato(enderecoContato);
		pedido.setQuantidade(quantidade);
		pedido.setTotal(total);
		pedido.setProduto(produto);
		
		new PedidoDAO().cadastrar(pedido);
		
		response.sendRedirect("listagens/listarPedidos.jsp");
		
	}

}
