package controle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import conexao.ProdutoDAO;
import modelo.Categoria;
import modelo.Produto;

/**
 * Servlet implementation class CadastroProdutosServlet
 */
@WebServlet(name = "cadastroproduto", urlPatterns = { "/cadastroproduto" })
public class CadastroProdutosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CadastroProdutosServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nomeProduto = request.getParameter("nome");
		String descricaoProduto = request.getParameter("descricao");
		Double precoProduto = Double.parseDouble(request.getParameter("preco"));
		Integer categoriaID = Integer.parseInt(request.getParameter("categoria"));
		
		Categoria categoria = new Categoria();
		categoria.setId(categoriaID);
		
		Produto produto = new Produto();
		produto.setNome(nomeProduto);
		produto.setDescricao(descricaoProduto);
		produto.setPreco(precoProduto);
		produto.setCategoria(categoria);
		
		new ProdutoDAO().cadastrar(produto);
		
		response.sendRedirect("listagens/listarProdutos.jsp");
		
	}

}













