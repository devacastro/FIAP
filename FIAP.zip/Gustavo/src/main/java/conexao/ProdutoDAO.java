package conexao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Categoria;
import modelo.Produto;

public class ProdutoDAO extends DAO {
	//M�todo para cadastrar produtos
	public void cadastrar(Produto produto) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
			
		sql = "INSERT INTO java_produto values (produto_sequence.nextval, ?, ?, ?, ?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produto.getCategoria().getId());
			ps.setString(2, produto.getNome());
			ps.setString(3, produto.getDescricao());
			ps.setDouble(4, produto.getPreco());
			ps.execute();
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro ao cadastrar produto\n" + e);
		}
			
	}
		
	//M�todo para retornar os dados dos produtos
	public List<Produto> listar() {
		List<Produto> lista = new ArrayList<Produto>();
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		Produto produto;
		Categoria categoria;
		
		sql = "SELECT P.nome, P.descricao, P.preco, P.produto_id, C.categoria as cnome FROM java_produto P, "
				+ "java_categoria C where P.categoria_id = C.categoria_id";
				
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				categoria = new Categoria();
				categoria.setCategoria(rs.getString("cnome"));
				produto = new Produto();
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
				produto.setPreco(rs.getDouble("preco"));
				produto.setId(rs.getInt("produto_id"));
				produto.setCategoria(categoria);
				lista.add(produto);
			}
			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao listar os dados dos produtos\n" + e);
		}
		return lista;
	}
		
}
