package conexao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Categoria;

public class CategoriaDAO extends DAO{
	

	
	public void cadastrar(Categoria categoria) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		
		sql = "INSERT INTO java_categoria values (categoria_sequence.nextval, ?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, categoria.getCategoria());
			ps.execute();
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro para cadastrar categoria\n" + e);
		}
		
	}
	

	
	public List<Categoria> listar() {
		List<Categoria> lista = new ArrayList<Categoria>();
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		Categoria categoria;
	
		sql = "SELECT * FROM java_categoria";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				categoria = new Categoria();
				categoria.setId(rs.getInt("categoria_id"));
				categoria.setCategoria(rs.getString("categoria"));
				lista.add(categoria);
			}
			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao listar os dados de categorias\n" + e);
		}
		return lista;
	}
	
}
