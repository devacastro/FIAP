package conexao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Pedido;
import modelo.Produto;

public class PedidoDAO extends DAO{
	
	//M�todo para cadastrar pedidos
	public void cadastrar(Pedido pedido) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
				
		sql = "INSERT INTO java_pedido values (pedido_sequence.nextval, ?, ?, SYSDATE)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, pedido.getNomeContato());
			ps.setString(2, pedido.getEnderecoContato());
			ps.execute();
			ps.close();

		} catch (SQLException e) {
			System.out.println("Erro ao cadastrar pedido\n" + e);
		}
			
		sql = "INSERT INTO java_pedidodetalhe values (detalhe_sequence.nextval, pedido_sequence.currval, ?, ?, ?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, pedido.getProduto().getId());
			ps.setInt(2, pedido.getQuantidade());
			ps.setDouble(3, pedido.getTotal());
			ps.execute();
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro ao cadastrar detalhe do pedido\n" + e);
		}
			
	}
			
	//M�todo para retornar os dados dos pedidos
	public List<Pedido> listar() {
		List<Pedido> lista = new ArrayList<Pedido>();
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		Pedido pedido;
		Produto produto;
			
		sql = "SELECT O.nome_contato as onome, P.nome as pnome, O.data as odata, D.quantidade, D.total, D.pedido_id FROM java_pedidodetalhe D "
				+ "INNER JOIN java_pedido O ON O.pedido_id = D.pedido_id "
				+ "INNER JOIN java_produto P ON P.produto_id = D.produto_id ORDER BY O.data";
					
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				produto = new Produto();
				produto.setNome(rs.getString("pnome")) ;
				pedido = new Pedido();
				pedido.setNomeContato(rs.getString("onome"));
				pedido.setProduto(produto);
				pedido.setData(rs.getString("odata"));
				pedido.setQuantidade(rs.getInt("quantidade"));
				pedido.setTotal(rs.getDouble("total"));
				pedido.setId(rs.getInt("pedido_id"));
				lista.add(pedido);
			}
			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao listar os dados dos pedidos\n" + e);
		}
		return lista;
	}
	
	//M�todo para apagar um pedido
	public void apagar(Integer pedido_id) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
				
		sql = "DELETE FROM java_pedidodetalhe WHERE pedido_id = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, pedido_id);
			ps.execute();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Erro ao apagar detalhe do pedido\n" + e);
		}
		
		sql = "DELETE FROM java_pedido WHERE pedido_id = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, pedido_id);
			ps.execute();
			ps.close();
		} catch (SQLException e) {
			System.out.println("Erro ao apagar pedido\n" + e);
		}

	}
	
}
